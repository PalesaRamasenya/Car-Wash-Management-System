package Entities;
public class Wash {
    
  private String washType;    

    public Wash(String washType) {
        this.washType = washType;
    }

    public String getWashType() {
        return washType;
    }

    public void setWashType(String washType) {
        this.washType = washType;
    }
    
}
