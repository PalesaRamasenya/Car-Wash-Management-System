package Entities;
import Entities.*;
import java.sql.Date;

public class Booking {
    private String bookingStatus;
    private String idNumber;
    private Wash wash;
    private Car car;

    public Booking(String bookingStatus, String idNumber, Wash wash, Car car) {
        this.bookingStatus = bookingStatus;
        this.idNumber = idNumber;
        this.wash = wash;
        this.car = car;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }
    
    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public Wash getWash() {
        return wash;
    }

    public void setWash(Wash wash) {
        this.wash = wash;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }
    
    
    
}
