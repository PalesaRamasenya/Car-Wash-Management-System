package Entities;

public class Car {
  private String registrationNumber;
  private String model;
  private String carType;

    public Car(String registrationNumber, String model, String carType) {
        this.registrationNumber = registrationNumber;
        this.model = model;
        this.carType = carType;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }
  
  
}
