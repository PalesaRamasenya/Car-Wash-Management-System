package Entities;

import java.util.Date;


public class Complaint {
    private String message;
    private String resolved;
    private String idNumber;
//    private Date date;

    public Complaint(String message, String resolved, String idNumber) {
        this.message = message;
        this.resolved = resolved;
        this.idNumber = idNumber;
      //  this.date = date;
    }

   
    
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getResolved() {
        return resolved;
    }

    public void setResolved(String resolved) {
        this.resolved = resolved;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }
   
}
