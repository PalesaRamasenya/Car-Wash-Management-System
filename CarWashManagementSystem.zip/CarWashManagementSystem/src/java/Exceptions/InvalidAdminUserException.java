package Exceptions;
public class InvalidAdminUserException extends Exception {

    public InvalidAdminUserException(String message) {
        super(message);
    }
    
}
