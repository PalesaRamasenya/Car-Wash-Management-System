package Database;

import Entities.Account;
import Entities.Booking;
import Entities.Car;
import Entities.Complaint;
import Entities.Customer;
import Entities.Wash;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

public final class CarWashManagerDatabase {

    private final Connection connection;

    public CarWashManagerDatabase() throws SQLException, ClassNotFoundException {
        this.connection = this.getConnection();
    }

    public final Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
                "jdbc:mysql://10.5.36.238:3306/carwashmanagementsystemdb?useSSL=false&&allowPublicKeyRetrieval=true",
                "perc",
                "percyy"
        );
    }

    /*   
    private boolean empty(String value){
        if(value.equals("")){
        thor
        }
    }*/
    public boolean addCustomer(Customer customer) throws SQLException {

        // Insert customer information into the customer table
        String sqlCustomer = "INSERT INTO carwashmanagementsystemdb.customer "
                + " VALUES (?, ?, ?, ?)";

        try (PreparedStatement psCustomer = connection.prepareStatement(sqlCustomer)) {
            psCustomer.setString(1, customer.getIdNumber());
            psCustomer.setString(2, customer.getFirstName());
            psCustomer.setString(3, customer.getLastName());
            psCustomer.setString(4, customer.getEmail());
            psCustomer.executeUpdate();
        }

        // Insert account information into the account table
        String sqlAccount = "INSERT INTO carwashmanagementsystemdb.account "
                + "VALUES (?, ?, ?,CURRENT_TIMESTAMP)";
        try (PreparedStatement psAccount = connection.prepareStatement(sqlAccount)) {
            psAccount.setString(1, customer.getAccount().getUsername());
            psAccount.setString(2, customer.getAccount().getPassword());
            psAccount.setString(3, customer.getIdNumber());
            psAccount.executeUpdate();
        }

        return true;
    }

    public boolean createBooking(Booking booking) throws SQLException {
        // Start a transaction
        connection.setAutoCommit(false);

        try {
            // Check if the customer exists
            if (!customerExists(booking.getIdNumber())) {
                throw new SQLException("Customer with ID " + booking.getIdNumber() + " does not exist.");
            }

            // Generate a unique booking ID
            int bookingId = generateRandomBookingId();

            // Insert booking information into the booking table
            String sqlBooking = "INSERT INTO carwashmanagementsystemdb.booking "
                    + "VALUES (?, ?, ?,CURRENT_TIMESTAMP)";
            try (PreparedStatement psBooking = connection.prepareStatement(sqlBooking)) {
                String status = booking.getBookingStatus();
                String customerId = booking.getIdNumber();

                psBooking.setInt(1, bookingId);
                psBooking.setString(2, status);
                psBooking.setString(3, customerId);
                psBooking.executeUpdate();
            }

            // Insert wash information into the wash table
            String sqlWash = "INSERT INTO carwashmanagementsystemdb.wash "
                    + "VALUES (?, ?, ?)";
            try (PreparedStatement psWash = connection.prepareStatement(sqlWash)) {
                int washId = generateRandomWashId();
                String washType = booking.getWash().getWashType();

                psWash.setInt(1, washId);
                psWash.setString(2, washType);
                psWash.setInt(3, bookingId);
                psWash.executeUpdate();
            }

            // Insert car information into the vehicle table
            String sqlCar = "INSERT INTO carwashmanagementsystemdb.vehicle "
                    + "VALUES (?, ?, ?, ?)";
            try (PreparedStatement psCar = connection.prepareStatement(sqlCar)) {
                String reg = booking.getCar().getRegistrationNumber();
                String model = booking.getCar().getModel();
                String type = booking.getCar().getCarType();

                psCar.setString(1, reg);
                psCar.setString(2, model);
                psCar.setString(3, type);
                psCar.setInt(4, bookingId);
                psCar.executeUpdate();
            }

            // Commit the transaction
            connection.commit();
            return true;
        } catch (SQLException ex) {
            // Rollback the transaction in case of exception
            connection.rollback();
            throw ex; // Re-throw the exception for handling in the calling code
        } finally {
            // Reset auto-commit mode
            connection.setAutoCommit(true);
        }
    }//end

// Method to check if the customer exists
    private boolean customerExists(String customerId) throws SQLException {
        String sql = "SELECT Id FROM carwashmanagementsystemdb.customer WHERE Id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

// Method to generate a unique random booking ID
    private int generateRandomBookingId() {
        Random random = new Random();
        return random.nextInt(100);
    }

// Method to generate a unique random wash ID
    private int generateRandomWashId() {
        Random random = new Random();
        return random.nextInt(100);
    }

    // Method to generate a unique random wash ID
    private int generateRandomComplaintId() {
        Random random = new Random();
        return random.nextInt(100);
    }

    public boolean createComplaint(Complaint complaint) throws SQLException {
        String sql = "INSERT INTO carwashmanagementsystemdb.complaint "
                + "VALUES(?,?,?,?,CURRENT_TIMESTAMP)";

        int complaintId = generateRandomComplaintId();

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, complaintId);
        ps.setString(2, complaint.getMessage());
        ps.setString(3, complaint.getResolved());
        ps.setString(4, complaint.getIdNumber());

        ps.executeUpdate();
        ps.close();
        return true;
    }//end

    public boolean updateBookingWashtype(int bookingId, String washType) throws SQLException {

        String sql = "UPDATE carwashmanagementsystemdb.wash "
                + "SET Washtype=?"
                + "WHERE Booking_id = ?";

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, washType);
        ps.setInt(2, bookingId);
        ps.executeUpdate();

        return true;
    }//end

    public String getDetails(String customer_id) throws SQLException, ClassNotFoundException {
        String sql = "SELECT * FROM carwashmanagementsystemdb.account "
                + "WHERE Customer_id = ? ";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, customer_id);

        ResultSet rs = ps.executeQuery();

        String password = "", username = "";
        if (rs.next()) {
            password = rs.getString("Password");
            username= rs.getString("Username");
        }
        return password + "#" + username;
    }//end

    public int getBookingId(String customerId) throws SQLException {

        String sql = "SELECT  Id FROM carwashmanagementsystemdb.booking "
                + "WHERE Customer_id = ?";

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, customerId);

        ResultSet rs = ps.executeQuery();
        int bookingId = 0;
        if (rs.next()) {
            bookingId = rs.getInt("Id");
        }

        rs.close();
        ps.close();
        return bookingId;
    }

    public boolean updateBookingStatus(int bookingId, String newBookingStatus) throws SQLException {

        String sql = "UPDATE carwashmanagementsystemdb.booking "
                + "SET Status=?"
                + "WHERE Id=?";

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, newBookingStatus);
        ps.setInt(2, bookingId);

        ps.executeUpdate();

        return true;
    }//end

    // The account table is a secondary table to primary table Account. The two are linked by the Customer_id foreign key
    public boolean updateLoginDetails(Account account, String customerId) throws SQLException {

        String sql = "UPDATE carwashmanagementsystemdb.account SET "
                + "Username = ?,"
                + "Password = ? "
                + "WHERE account.Customer_id = ?";

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, account.getUsername());
        ps.setString(2, account.getPassword());
        ps.setString(3, customerId);

        ps.executeUpdate();
        ps.close();
        return true;
    }//end

    public boolean updateEmail(String email, String customerId) throws SQLException {

        String sql = "UPDATE carwashmanagementsystemdb.customer SET "
                + "Email = ? "
                + "WHERE Id = ?";

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, email);
        ps.setString(2, customerId);

        ps.executeUpdate();
        ps.close();

        return true;
    }//end

    public String getBookingStatus(int bookingId) throws SQLException {

        String sql = "SELECT Status FROM carwashmanagementsystemdb.booking "
                + "INNER JOIN carwashmanagementsystemdb.vehicle ON vehicle.Booking_id = booking.Id "
                + "INNER JOIN carwashmanagementsystemdb.wash ON wash.Booking_id = booking.Id "
                + "WHERE booking.Id=?";

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, bookingId);

        ResultSet rs = ps.executeQuery();
        String bookingStatus = "";
        if (rs.next()) {
            bookingStatus = rs.getString("Status");
        }
        return bookingStatus;
    }//end

    public ArrayList<Booking> viewAllBookings() throws SQLException {

        String sql = "SELECT * FROM carwashmanagementsystemdb.booking AS b "
                + "INNER JOIN carwashmanagementsystemdb.vehicle AS v ON v.Booking_id = b.Id "
                + "INNER JOIN carwashmanagementsystemdb.wash AS w ON w.Booking_id = b.Id";

        ArrayList<Booking> bookings = new ArrayList<>();

        try (PreparedStatement ps = connection.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String bookingStatus = rs.getString("Status");
                String reg = rs.getString("RegistrationNumber");
                String carModel = rs.getString("Model");
                String carType = rs.getString("Type");
                String washType = rs.getString("Washtype");
                String customerId = rs.getString("Booking_id");

                // Create Booking object
                Booking booking = new Booking(bookingStatus, customerId, new Wash(washType), new Car(reg, carModel, carType));
                bookings.add(booking);
            }
        }

        return bookings;
    }

    public ArrayList<Customer> viewAllCreatedAccounts() throws SQLException {

        String sql = "SELECT * FROM carwashmanagementsystemdb.customer "
                + "INNER JOIN carwashmanagementsystemdb.account ON Customer_id = Id";

        PreparedStatement ps = connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        Customer customer = null;
        ArrayList<Customer> customers = new ArrayList<>();

        while (rs.next()) {
            String name = rs.getString("Name");
            String surname = rs.getString("Surname");
            String email = rs.getString("Email");

            String username = rs.getString("Username");
            String password = rs.getString("Password");

            String idNumber = rs.getString("Id");
            Account account = new Account(username, password);
            customer = new Customer(name, surname, idNumber, email, account);

            customers.add(customer);
        }
        return customers;
    }//end

    public ArrayList<Complaint> viewAllComplaints() throws SQLException {

        String sql = "SELECT * FROM complaint ";

        PreparedStatement ps = connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        ArrayList<Complaint> complains = new ArrayList<>();

        while (rs.next()) {
            Complaint complaint = new Complaint(rs.getString("Message"), rs.getString("Resolved"), rs.getString("Customer_id"));
            complains.add(complaint);
        }
        return complains;
    }//end

    public boolean deleteAccount(String customerId) throws SQLException {
        // Start a transaction
        connection.setAutoCommit(false);

        try {
            // Delete from the account table first
            String sqlAccount = "DELETE FROM account WHERE Customer_id=?";
            try (PreparedStatement psAccount = connection.prepareStatement(sqlAccount)) {
                psAccount.setString(1, customerId);
                psAccount.executeUpdate();
            }

            // Then delete from the customer table
            String sqlCustomer = "DELETE FROM customer WHERE Id=?";
            try (PreparedStatement psCustomer = connection.prepareStatement(sqlCustomer)) {
                psCustomer.setString(1, customerId);
                psCustomer.executeUpdate();
            }

            // Commit the transaction
            connection.commit();
            return true;
        } catch (SQLException ex) {
            // Rollback the transaction in case of exception
            connection.rollback();
            throw ex; // Re-throw the exception for handling in the calling code
        } finally {
            // Reset auto-commit mode and close resources
            connection.setAutoCommit(true);
        }
    }

    public ArrayList<Booking> viewWashedCars() throws SQLException {

        String sql = "SELECT * FROM carwashmanagementsystemdb.booking "
                + "INNER JOIN carwashmanagementsystemdb.vehicle ON vehicle.Booking_id = booking.Id "
                + "INNER JOIN carwashmanagementsystemdb.wash ON wash.Booking_id = booking.Id "
                + "WHERE booking.Status=?";

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, "FINISHED");

        ResultSet rs = ps.executeQuery();

        ArrayList<Booking> bookings = new ArrayList<>();
        while (rs.next()) {
            String carType = rs.getString("Type");
            String model = rs.getString("Model");
            String reg = rs.getString("RegistrationNumber");
            String washtype = rs.getString("Washtype");
            String status = rs.getString("Status"); // Retrieve booking status from the database
            String customerId = rs.getString("Customer_id"); // Retrieve customer ID from the database

            Car car = new Car(reg, model, carType);
            Wash wash = new Wash(washtype);

            // Create Booking object with retrieved details
            Booking booking = new Booking(status, customerId, wash, car);
            bookings.add(booking);
        }

        // Close resources
        rs.close();
        ps.close();

        return bookings;
    }

}
