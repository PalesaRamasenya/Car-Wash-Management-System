package Controller;

import Database.CarWashManagerDatabase;
import Exceptions.CustomerDoesNotHaveBookingException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateBookingStatusAdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String newBookingStatus = request.getParameter("bookingStatus");
        int bookingId = Integer.parseInt(request.getParameter("bookingID"));

        CarWashManagerDatabase connection = null;

        try {
            connection = new CarWashManagerDatabase();

            boolean doesBookingIdExist = checkIfBookingIdExists(connection, bookingId);

            if (!doesBookingIdExist) {
                throw new CustomerDoesNotHaveBookingException("There is not Customer with such a booking id("+bookingId+")");
            } else {
                connection.updateBookingStatus(bookingId, newBookingStatus);
            }

        } catch (SQLException ex) {
            Logger.getLogger(CreateBookingAdminServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateBookingStatusAdminServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (CustomerDoesNotHaveBookingException e) {
           request.setAttribute("CustomerDoesNotHaveBookingException", e);
           request.getRequestDispatcher("CustomerDoesNotHaveBookingException.jsp").forward(request, response);

        }

        request.setAttribute("bookingStatus", newBookingStatus);

        request.getRequestDispatcher("UpdateBookingStatusAdminDisplay.jsp").forward(request, response);
    }

    public boolean checkIfBookingIdExists(CarWashManagerDatabase connection, int bookingId)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT  Id FROM carwashmanagementsystemdb.booking "
                + "WHERE Id = ?";

        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ps.setInt(1, bookingId);

        ResultSet rs = ps.executeQuery();
        return rs.next();
    }//end
}
