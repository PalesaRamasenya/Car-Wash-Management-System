package Controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SummaryServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("C:\\Users\\pales\\Desktop\\SummaryReport.txt")));

        bw.write("            This car wash management system has processed a total of 9 washed\n"
                + "            cars, with a breakdown by vehicle type as follows: 3 Vans, \n"
                + "            7 SUVs, 2 Trucks, 2 Convertibles, 3 Sedans, and 1 car categorized under 'Other' models. Among the available wash types, \n"
                + "            4 customers opted for Automatic Car Wash, 6 customers chose Self Service Car Wash, and 8 customers selected Full Service\n"
                + "            Car Wash. Notably, the most preferred wash type is Full Service \n"
                + "            Car Wash, while the least favored is Automatic Car Wash. Below is the summary of car models, their types, and corresponding wash types:");
        bw.write(" In this car wash management system, there have been a total of 18 bookings. Out of these, 9 bookings have been fulfilled, \n"
                + "            while the remaining 9 bookings are yet to be started. None of the bookings are currently halfway through.");
        bw.write("In this car wash management system, a total of 6 complaints \n"
                + "            were received from customers. Out of these, 3 complaints have been successfully resolved, \n"
                + "            while 3 remain unresolved. The complaints varied from long waiting times for car washing, the car wash running \n"
                + "            out of water, improper cleaning of rearview mirrors, dissatisfaction with interior spray scent, and missing diamond earrings placed on the dashboard. \n"
                + "");
        bw.write("This car wash management system oversees \n" +
"            23 accounts, with a gender distribution of 19 female customers \n" +
"            and 4 male customers. Regarding age demographics, the system caters to various age groups: \n" +
"            1 customer in the Child category, 8 in the Young Adult segment, 5 in the Adult group, 3 in the Middle\n" +
"            Aged Adult bracket, 5 in the Older Adult category, and 1 in the Senior group. This comprehensive overview \n" +
"            assists in tailoring services and optimizing operations to meet the diverse needs of customers across different demographics.");

        bw.close();
        String filePath = "C:\\Users\\pales\\Desktop\\SummaryReport.txt";
        File downloadFile = new File(filePath);
        FileInputStream inStream = new FileInputStream(downloadFile);

        String relativePath = getServletContext().getRealPath("");
        System.out.println("Relative path: " + relativePath);

        ServletContext context = getServletContext();

        String mimeType = context.getMimeType(filePath);
        if (mimeType == null) {
            mimeType = "application/octet-stream";

        }
        System.out.println("Mine type: " + mimeType);

        response.setContentType(mimeType);

        response.setContentLength((int) downloadFile.length());

        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
        response.setHeader(headerKey, headerValue);

        OutputStream outStream = response.getOutputStream();

        byte[] buffer = new byte[4096];
        int byteRead = 0;
        while ((byteRead = inStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, byteRead);

            inStream.close();
            outStream.close();
        }
    }
}
