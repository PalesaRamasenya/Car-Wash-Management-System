package Controller;

import Database.CarWashManagerDatabase;
import Exceptions.CustomerDoesNotHaveBookingException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewBookingStatusUserServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String status = "";

        try {
            CarWashManagerDatabase connection = new CarWashManagerDatabase();

            String customer_id = (String) request.getSession(true).getAttribute("Customer_id");

            int id = connection.getBookingId(customer_id);

            if (id == 0) {
                throw new CustomerDoesNotHaveBookingException("Customer does not have a booking. Got to admin!");
            }
            status = connection.getBookingStatus(id);

        } catch (SQLException ex) {
            Logger.getLogger(ViewBookingStatusUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ViewBookingStatusUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        request.setAttribute("bookingStatus", status);

        request.getRequestDispatcher("ViewBookingStatusUserDisplay.jsp").forward(request, response);
    }

}
