package Controller;

import Database.CarWashManagerDatabase;
import Entities.Complaint;
import Exceptions.CustomerDoesNotHaveBookingException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LodgeComplaintUserServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String message = request.getParameter("message");
        String customerId = request.getSession(true).getAttribute("Customer_id").toString();
        
      
        
        try {

            Complaint complaint = new Complaint(message, "NOT RESOLVED", customerId);

            CarWashManagerDatabase connection = new CarWashManagerDatabase();

            int bookingid = connection.getBookingId(customerId);

            if (bookingid == 0) {
                throw new CustomerDoesNotHaveBookingException("You do not have a booking, this means you cannot lodge  a complaint");
            } else {
               
                connection.createComplaint(complaint);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LodgeComplaintUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LodgeComplaintUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        request.getRequestDispatcher("UserSideMenu.jsp").forward(request,response);
    }

    private boolean doesCustomerExist(CarWashManagerDatabase connection, String customer_id)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT * FROM carwashmanagementsystemdb.customer "
                + "WHERE Id=?";

        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ps.setString(1, customer_id);

        ResultSet rs = ps.executeQuery();

        return rs.next();
    }//end
}
