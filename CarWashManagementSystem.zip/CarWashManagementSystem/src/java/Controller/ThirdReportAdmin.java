package Controller;

import Database.CarWashManagerDatabase;
import Entities.Complaint;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ThirdReportAdmin extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("C:\\Users\\pales\\Desktop\\ComplaintsReport.txt")));

        CarWashManagerDatabase connection = null;
        String resolvedStr = "Number of solved Complaints:";
        String unResolvedStr = "Number of unsolved Complaints: ";
        String numOfComplaintStr = "Number of Complaints received: ";

         
        try {

            connection = new CarWashManagerDatabase();

            int numOfComplaints = getNumberofComplaints(connection);
            
            int numOfResolved = 0, numOfUnresolved = 0;
            ArrayList<Complaint> complains = connection.viewAllComplaints();
            int resolvedIndex = 0;
            
            ArrayList<Complaint> complainList = connection.viewAllComplaints();
            
            for (Complaint complain : complains) {

                //determine number of resolved complaints
                String resolved = complain.getResolved();
                if (resolved.equals("RESOLVED")) {

                    numOfResolved++;
                    
                    
                } else {
                    numOfUnresolved++;
                }

                bw.write("Message: "+complain.getMessage()+"\n\n");
                bw.write("Resolved: "+complain.getResolved()+"\n\n");
                bw.write("Customer ID: "+complain.getIdNumber()+"\n\n\n\n");
            }

            unResolvedStr += numOfUnresolved;
            resolvedStr += numOfResolved;
            numOfComplaintStr += numOfComplaints;
            
           
            //save to files
            bw.write(numOfComplaintStr + "\n");
            bw.write(unResolvedStr + "\n");
            bw.write(resolvedStr + "\n");
            
            //set request attributes
            request.setAttribute("resolved", resolvedStr);
            request.setAttribute("unresolved", unResolvedStr);
            request.setAttribute("numOfComplaints", numOfComplaintStr);
            request.setAttribute("complainList",complainList );

        } catch (SQLException ex) {
            Logger.getLogger(ThirdReportAdmin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ThirdReportAdmin.class.getName()).log(Level.SEVERE, null, ex);

        }
        bw.close();

        request.getRequestDispatcher("ThirdReportAdminDisplay.jsp").forward(request, response);
    }

    private int getNumberofComplaints(CarWashManagerDatabase connection)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT COUNT(Id) AS count FROM carwashmanagementsystemdb.complaint";
        // Using try-with-resources to ensure resources are closed properly
        try (
                PreparedStatement ps = connection.getConnection().prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            // Retrieve the number of complaints
            if (rs.next()) {
                return rs.getInt("count");
            } else {
                // In case the result set is empty
                return 0;
            }
        }
    }
}
