package Controller;

import Database.CarWashManagerDatabase;
import Exceptions.EmailAlreadyUsedException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateEmailUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");

        try {

            CarWashManagerDatabase connection = new CarWashManagerDatabase();

            if (checkIfEmailExists(connection, email)) {
                throw new EmailAlreadyUsedException(email + " is already used for another account.");
            } else {

                String customerId = request.getSession(true).getAttribute("Customer_id").toString();
                connection.updateEmail(email, customerId);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UpdateEmailUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateEmailUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        }catch(EmailAlreadyUsedException e){
            request.setAttribute("EmailAlreadyUsedException", e);
            request.getRequestDispatcher("/EmailAlreadyUsedException.jsp").forward(request, response);
            
        }

        request.getRequestDispatcher("UpdateEmailUserDisplay.jsp").forward(request, response);
    }

    private boolean checkIfEmailExists(CarWashManagerDatabase connection, String email)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT Email FROM carwashmanagementsystemdb.customer "
                + "INNER JOIN carwashmanagementsystemdb.account ON account.Customer_id = customer.Id "
                + "WHERE customer.Email = ? ";
        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ps.setString(1, email);

        ResultSet rs = ps.executeQuery();
        return rs.next();
    }//end

}
