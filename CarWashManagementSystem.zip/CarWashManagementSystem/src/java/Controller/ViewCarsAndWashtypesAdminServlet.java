package Controller;

import Database.CarWashManagerDatabase;
import Entities.Booking;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/ViewCarsAndWashtypesAdminServlet")
public class ViewCarsAndWashtypesAdminServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<Booking> bookings = new ArrayList<>();

        try {
            CarWashManagerDatabase connection = new CarWashManagerDatabase();
            bookings = connection.viewAllBookings();

        } catch (SQLException ex) {
            Logger.getLogger(ViewCarsAndWashtypesAdminServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ViewCarsAndWashtypesAdminServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        request.setAttribute("bookings", bookings);

        request.getRequestDispatcher("ViewCarModelsAndWashtypesAdminDisplay.jsp").forward(request, response);

    }
}
/*
 StandardWrapperValve[ViewCarsAndWashtypesAdminServlet]: Servlet.service() for servlet ViewCarsAndWashtypesAdminServlet threw exception
org.apache.jasper.JasperException: PWC6033: Error in Javac compilation for JSP
PWC6199: Generated servlet error:
source value 1.5 is obsolete and will be removed in a future release
PWC6199: Generated servlet error:
target value 1.5 is obsolete and will be removed in a future release
PWC6199: Generated servlet error:
To suppress warnings about obsolete options, use -Xlint:-options.
PWC6199: Generated servlet error:
'try' without 'catch' or 'finally'
PWC6199: Generated servlet error:
illegal start of type
PWC6199: Generated servlet error:
illegal start of type
PWC6199: Generated servlet error:
';' expected
PWC6199: Generated servlet error:
<identifier> expected
PWC6199: Generated servlet error:
<identifier> expected
PWC6199: Generated servlet error:
class, interface, or enum expected
*/