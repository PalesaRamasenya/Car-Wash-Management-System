package Controller;

import Database.CarWashManagerDatabase;
import Exceptions.DoesNotHaveAccountException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RetrievePasswordUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id"), password="", username="";

        try {

            CarWashManagerDatabase connection = new CarWashManagerDatabase();
            boolean customerExist = this.usernameExists(connection,id);

            if (customerExist) {    
                String[] info  = connection.getDetails(id).split("#");
                password = info[0];
                username = info[1];
            } else {
                throw new DoesNotHaveAccountException("There is no user with the provided ID Number(" +id + ")");
            }
        } catch (SQLException ex) {
            Logger.getLogger(RetrievePasswordUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RetrievePasswordUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DoesNotHaveAccountException e) {
            request.setAttribute("DoesNotHaveAccountException", e);
            request.getRequestDispatcher("/DoesNotHaveAccountException.jsp").forward(request, response);
        }

        request.setAttribute("username",username);
        request.setAttribute("password",password);
        
        request.getRequestDispatcher("RetrieveDetailsUserDisplay.jsp").forward(request, response);
    }

    private boolean usernameExists(CarWashManagerDatabase connection, String customer_id) throws SQLException, ClassNotFoundException {
        String sql = "SELECT * FROM carwashmanagementsystemdb.account "
                + "WHERE Customer_id  = ? ";
        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ps.setString(1,customer_id);
        ResultSet rs = ps.executeQuery();

        return rs.next();
    }//end

}
