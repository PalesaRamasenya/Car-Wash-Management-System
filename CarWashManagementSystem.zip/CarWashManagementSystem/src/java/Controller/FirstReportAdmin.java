package Controller;

import Database.CarWashManagerDatabase;
import Entities.Customer;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FirstReportAdmin extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("C:\\Users\\pales\\Desktop\\CustomerReport.txt")));

        CarWashManagerDatabase connection = null;

        String numOfAccounts = "Number of Accounts: ";

        try {

            connection = new CarWashManagerDatabase();

            ArrayList<Customer> customers = connection.viewAllCreatedAccounts();

            // customers per gender
            int males = 0;
            int females = 0;
            String gender = "Male";
            String numOfFemales = "";
            String numOfMales = "";

            //age groups
            String childStr = "Customers in the Child age group: ", youngAdultStr = "Customers in the Young Adult age group: ", adultStr = "Customers in the Adult age group: ", midleAgedAdultStr = "Customers in the Middle Aged Adult age group: ",
                    olderAdultStr = "Customers in the Older Adult age group: ", seniorStr = "Customers in the Senior age group: ";

            // determines the number of customers per gender
            for (Customer customer : customers) {

                String id = customer.getIdNumber();//001212/1462/832
                int genderInt = Integer.parseInt(id.substring(6, 10));

                if (genderInt >= 0000 && genderInt <= 4999) {
                    gender = "Female";
                    females++;
                } else {
                    males++;
                }
            }//end loop

            //determines the age group of different customers
            int child = 0, youngAdult = 0, adult = 0, midleAgedAdult = 0, olderAdult = 0, senior = 0;
            for (Customer customer : customers) {

                String id = customer.getIdNumber();//001212/1462/832

                LocalDate birthDate = extractBirthDate(id);
                int age = calculateAge(birthDate);
                String ageGroup = determineAgeGroup(age);

                if (ageGroup.equals("Child")) {
                    child++;
                } else if (ageGroup.equals("Young Adult")) {
                    youngAdult++;
                } else if (ageGroup.equals("Adult")) {
                    adult++;
                } else if (ageGroup.equals("Middle-aged Adult")) {
                    midleAgedAdult++;
                } else if (ageGroup.equals("Older Adult")) {
                    olderAdult++;
                } else if (ageGroup.equals("Senior")) {
                    senior++;
                }

            }//end loop

            //Give values to file strings
            
            //give values to age groups
            childStr += child;
            youngAdultStr += youngAdult;
            adultStr += adult;
            midleAgedAdultStr += midleAgedAdult;
            olderAdultStr += olderAdult;
            seniorStr += senior;

            //genders
            numOfFemales = "The number of female Customers: " + females;
            numOfMales = "The number of male Customers: " + males;

            
            numOfAccounts += this.getNumberofCustomers(connection) + "\n";

            //write file strings to files
            bw.write(numOfAccounts);
            bw.write(numOfFemales + "\n");
            bw.write(numOfMales + "\n");

            bw.write(childStr+"\n");
            bw.write(youngAdultStr+"\n");
            bw.write(adultStr+"\n");
            bw.write(midleAgedAdultStr+"\n");
            bw.write(olderAdultStr+"\n");
            bw.write(seniorStr+"\n");
            
            //set request object
            request.setAttribute("numOfAccounts", numOfAccounts);
            request.setAttribute("numOfMales", numOfMales);
            request.setAttribute("numOfFemales", numOfFemales);

            bw.write(childStr+"\n");
            bw.write(youngAdultStr+"\n");
            bw.write(adultStr+"\n");
            bw.write(midleAgedAdultStr+"\n");
            bw.write(olderAdultStr+"\n");
            bw.write(seniorStr+"\n");
            
            request.setAttribute("childStr",childStr);
            request.setAttribute("youngAdultStr",youngAdultStr);
            request.setAttribute("adultStr",adultStr);
            request.setAttribute("midleAgedAdultStr",midleAgedAdultStr);
            request.setAttribute("olderAdultStr",olderAdultStr);
            request.setAttribute("seniorStr",seniorStr);
            request.setAttribute("customers",customers);
            
        } catch (SQLException ex) {
            Logger.getLogger(FirstReportAdmin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FirstReportAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }

        bw.close();

        request.getRequestDispatcher("FirstReportAdminDisplay.jsp").forward(request, response);
    }

    public static LocalDate extractBirthDate(String idNumber) {
        String dateString = idNumber.substring(0, 6); // Extract YYMMDD part
        int year = Integer.parseInt(dateString.substring(0, 2));
        int month = Integer.parseInt(dateString.substring(2, 4));
        int day = Integer.parseInt(dateString.substring(4, 6));

        // Assume 1900 for years 00-49 and 2000 for years 50-99
        year += (year < 50) ? 2000 : 1900;

        return LocalDate.of(year, month, day);
    }

    public static int calculateAge(LocalDate birthDate) {
        LocalDate currentDate = LocalDate.now();
        return currentDate.getYear() - birthDate.getYear();
    }

    public static String determineAgeGroup(int age) {
        if (age <= 17) {
            return "Child";
        } else if (age <= 24) {
            return "Young Adult";
        } else if (age <= 34) {
            return "Adult";
        } else if (age <= 44) {
            return "Middle-aged Adult";
        } else if (age <= 64) {
            return "Older Adult";
        } else {
            return "Senior";
        }
    }

    private int getNumberofCustomers(CarWashManagerDatabase connection)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT COUNT(Id) AS count FROM carwashmanagementsystemdb.customer";
        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        int numOfCustomers = 0;
        if (rs.next()) {
            numOfCustomers = rs.getInt("count");
        }
        rs.close();
        ps.close();
        return numOfCustomers;
    }
}
