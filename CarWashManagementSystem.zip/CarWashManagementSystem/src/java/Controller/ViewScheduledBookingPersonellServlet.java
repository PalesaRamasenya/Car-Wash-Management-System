
package Controller;

import Database.CarWashManagerDatabase;
import Entities.Booking;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewScheduledBookingPersonellServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
             ArrayList<Booking> bookings =  new ArrayList<>();
     
        try {
            
            CarWashManagerDatabase connection = new CarWashManagerDatabase();
            bookings = connection.viewAllBookings();
            
        } catch (SQLException ex) {Logger.getLogger(CreateBookingAdminServlet.class.getName()).log(Level.SEVERE, null, ex);} catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateBookingStatusAdminServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
              
                request.setAttribute("bookings",bookings);
        request.getRequestDispatcher("ViewScheduledBookingsPersonellDisplay.jsp").forward(request,response);
    }
}
