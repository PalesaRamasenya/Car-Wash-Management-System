package Controller;

import Database.CarWashManagerDatabase;
import Entities.Account;
import Exceptions.DoesNotHaveAccountException;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(true);

        String enteredUsername = request.getParameter("username");
        String enteredPassword = request.getParameter("password");

        String url = "";
        if (enteredPassword.equals("admin") && enteredUsername.equals("admin")) {
            url = "AdminSideMenu.jsp";
            session.setAttribute("adminuser", enteredUsername);
            session.setAttribute("adminpassword", enteredPassword);

            //remove customer and personell login details when user re-logins
            session.removeAttribute("username");
            session.removeAttribute("password");
            session.removeAttribute("personelluser");
            session.removeAttribute("personellpassword");

        } else if (enteredPassword.equals("personell") && enteredUsername.equals("personell")) {

            url = "PersonellSideMenu.jsp";
            session.setAttribute("personelluser", enteredPassword);
            session.setAttribute("personellpassword", enteredPassword);

            //remove customer and admin login details when user re-logins
            session.removeAttribute("username");
            session.removeAttribute("password");
            session.removeAttribute("adminuser");
            session.removeAttribute("adminpassword");

        } else {

            try {

                CarWashManagerDatabase connection = new CarWashManagerDatabase();
                Account account = new Account(enteredUsername, enteredPassword);

                boolean customerAccountExist = checkIfUserCanLogin(connection, account);

                if (customerAccountExist) {//allow customer to login

                    url = "UserSideMenu.jsp";
                    session.setAttribute("username", enteredUsername);
                    session.setAttribute("password", enteredPassword);

                    //remove admin login details when user re-logins
                    session.removeAttribute("adminuser");
                    session.removeAttribute("adminpassword");
                    session.removeAttribute("personelluser");
                    session.removeAttribute("personellpassword");

                    //save customer id into a session
                    String Customer_id = getCustomerId(connection, account);
                    session.setAttribute("Customer_id", Customer_id);

                } else {

                    throw new DoesNotHaveAccountException("You do not have an account.");
                    // url = "InvalidAdminUserErrorPage.jsp";
                }
            } catch (SQLException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DoesNotHaveAccountException e) {
                request.setAttribute("DoesNotHaveAccountException", e);
                request.getRequestDispatcher("DoesNotHaveAccountException.jsp").forward(request, response);

            }

        }

        request.getRequestDispatcher(url).forward(request, response);
    }

    private final boolean checkIfUserCanLogin(CarWashManagerDatabase connection, Account account)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT * FROM carwashmanagementsystemdb.customer "
                + "INNER JOIN carwashmanagementsystemdb.account ON customer.Id = account.Customer_id "
                + "WHERE Password=? AND Username=?";

        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ps.setString(1, account.getPassword());
        ps.setString(2, account.getUsername());

        ResultSet rs = ps.executeQuery();

        boolean hasNext = rs.next();
        ps.close();
        rs.close();

        return hasNext;
    }//end

    private final String getCustomerId(CarWashManagerDatabase connection, Account account) throws SQLException, ClassNotFoundException {

        String sql = "SELECT * FROM carwashmanagementsystemdb.customer "
                + "INNER JOIN carwashmanagementsystemdb.account ON customer.Id = account.Customer_id "
                + "WHERE Password=? AND Username=?";

        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ps.setString(1, account.getPassword());
        ps.setString(2, account.getUsername());

        ResultSet rs = ps.executeQuery();
        String id = "";
        if (rs.next()) {
            id = rs.getString("Id");
        }

        rs.close();
        ps.close();
        return id;
    }//end

}
