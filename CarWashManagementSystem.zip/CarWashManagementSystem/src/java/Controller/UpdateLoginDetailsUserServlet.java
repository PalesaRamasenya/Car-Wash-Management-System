package Controller;

import Database.CarWashManagerDatabase;
import Entities.Account;
import Exceptions.InvalidPasswordException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateLoginDetailsUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        
            try {
                Account account = new Account(username, password);

                CarWashManagerDatabase connection = new CarWashManagerDatabase();

                
                    if (isValidPassword(password)) {
                        
                        String customerId = request.getSession(true).getAttribute("Customer_id").toString();
                        connection.updateLoginDetails(account, customerId);

                    } else {
                        throw new InvalidPasswordException("Your password does not conform to our password standards. A Valid password should have: \n\n"
                                +"8 or more characters,\n"
                                +"2 or more uppercase,\n"
                                +"2 0r more digits,\n"
                                +"1 or more lowercase, and \n"
                                +"1 or more specila characters\n"
                                );
                    }
            } catch (SQLException ex) {
                Logger.getLogger(UpdateLoginDetailsUserServlet.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(UpdateLoginDetailsUserServlet.class.getName()).log(Level.SEVERE, null, ex);
            }catch(InvalidPasswordException e){
            request.setAttribute("InvalidPasswordException", e);
            request.getRequestDispatcher("/InvalidPasswordException.jsp").forward(request, response);
            
        }
        

        request.getRequestDispatcher("UpdateLoginDetailsUserDisplay.jsp").forward(request, response);
    }


    private String encyptPassword(String password) {

        String encryptedPassword = "";
        for (int i = 0; i < password.length(); i++) {

            char singleChar = password.charAt(i);
            int integerCharacterValue = (int) singleChar;
            int integerPlacesAway = 0;

            if (integerCharacterValue % 2 == 0) {//even number

                integerPlacesAway = 2;
                integerCharacterValue += integerPlacesAway;

            } else {//odd number

                integerPlacesAway = 2;
                integerCharacterValue -= integerPlacesAway;
            }
            encryptedPassword += Character.toString((char) integerCharacterValue);
        }
        return encryptedPassword;
    }//end

    private boolean isValidPassword(String password) {
        int lower = 0, upper = 0, digit = 0, special = 0, characters = 0;

        for (char singlerChar : password.toCharArray()) {
            characters++;
            if (Character.isLetter(singlerChar)) {

                if (Character.isUpperCase(singlerChar)) {
                    upper++;
                } else {
                    lower++;
                }

            } else if (Character.isDigit(singlerChar)) {
                digit++;
            } else if (!Character.isLetterOrDigit(singlerChar)) {
                special++;
            }
        }//end loop

        return (characters >= 8 && upper >=1 && lower >= 2 && digit>=2 && special >= 1);
    }//end

}
