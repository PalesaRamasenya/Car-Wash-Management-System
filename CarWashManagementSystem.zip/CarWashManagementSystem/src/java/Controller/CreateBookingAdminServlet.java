package Controller;

import Database.CarWashManagerDatabase;
import Entities.Booking;
import Entities.Car;
import Entities.Wash;
import Exceptions.DoesNotHaveAccountException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CreateBookingAdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String model = request.getParameter("carModel");
        String regNumber = request.getParameter("registrationNumber");
        String carType = request.getParameter("carType");

        String washType = request.getParameter("typeOfWash");

        String idNumber = request.getParameter("idNumber");

        if (model.equals("") || regNumber.equals("") || carType.equals("") || washType.equals("")) {

            //throw new EmptyFieldSubmissionException("You must enter all fields!");
        } else {

            Car car = new Car(regNumber, model, carType);
            Wash wash = new Wash(washType);
            Booking booking = new Booking("NOT YET STARTED", idNumber, wash, car);

            try {
                CarWashManagerDatabase connection = new CarWashManagerDatabase();

                if (!doesCustomerExist(connection, idNumber)) {
                    throw new DoesNotHaveAccountException("You have to create an account before we create a booking for you");
                }else{
                
                    connection.createBooking(booking);//create booking for customer
                }
            } catch (SQLException ex) {
                Logger.getLogger(CreateBookingAdminServlet.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CreateBookingAdminServlet.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        request.getRequestDispatcher("BookingCreatedInfoDisplay.jsp").forward(request, response);
    }

    private boolean doesCustomerExist(CarWashManagerDatabase connection, String customer_id)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT * FROM carwashmanagementsystemdb.customer "
                + "WHERE Id=?";

        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ps.setString(1, customer_id);

        ResultSet rs = ps.executeQuery();

        return rs.next();
    }//end

}
