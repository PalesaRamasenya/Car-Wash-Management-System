package Controller;

import Database.CarWashManagerDatabase;
import Exceptions.CannotChangeBookingDetailsException;
import Exceptions.CustomerDoesNotHaveBookingException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdateBookingWashtypeUserServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String typeOfWash = request.getParameter("typeOfWash");

        CarWashManagerDatabase connection = null;

        try {

            connection = new CarWashManagerDatabase();

            String customer_id = (String) request.getSession(true).getAttribute("Customer_id");

            int id = connection.getBookingId(customer_id);
            if (id == 0) {
                throw new CustomerDoesNotHaveBookingException("Customer does not have a booking. Got to admin!");
            } else {
                String status = getBookingStatus(connection, id);

                if (status.equals("NOT YET STARTED")) {
                    connection.updateBookingWashtype(id, typeOfWash);
                } else {
                    throw new CannotChangeBookingDetailsException("Booking status is " + status + ",meaning it is in process."
                            + " This means you cannot change the washtype");
                }

            }

        } catch (SQLException ex) {
            Logger.getLogger(UpdateBookingWashtypeUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateBookingWashtypeUserServlet.class.getName()).log(Level.SEVERE, null, ex);
        }catch(CannotChangeBookingDetailsException e){
            request.setAttribute("CannotChangeBookingDetailsException", e);
            request.getRequestDispatcher("/CannotChangeBookingDetailsException.jsp").forward(request, response);
            
        }catch(CustomerDoesNotHaveBookingException e){
            request.setAttribute("CustomerDoesNotHaveBookingException", e);
            request.getRequestDispatcher("/CustomerDoesNotHaveBookingException.jsp").forward(request, response);
            
        }

        request.setAttribute("washtype",typeOfWash);
        request.getRequestDispatcher("UpdateBookingWashtypeUserDisplay.jsp").forward(request, response);
    }

    public String getBookingStatus(CarWashManagerDatabase connection, int bookingId)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT Status FROM carwashmanagementsystemdb.booking "
                + "INNER JOIN carwashmanagementsystemdb.vehicle ON vehicle.Booking_id = booking.Id "
                + "INNER JOIN carwashmanagementsystemdb.wash ON wash.Booking_id = booking.Id "
                + "WHERE booking.Id=? ";

        PreparedStatement ps = connection.getConnection().prepareStatement(sql);
        ps.setInt(1, bookingId);

        ResultSet rs = ps.executeQuery();
        String bookingStatus = "";
        if (rs.next()) {
            bookingStatus = rs.getString("Status");
        }
        return bookingStatus;
    }//end
}
