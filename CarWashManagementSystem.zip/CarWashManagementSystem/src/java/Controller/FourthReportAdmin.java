package Controller;

import Database.CarWashManagerDatabase;
import Entities.Booking;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FourthReportAdmin extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("C:\\Users\\pales\\Desktop\\BookingsReport.txt")));

        CarWashManagerDatabase connection;
        int numOfHalfway = 0;
        int numOfNotYet = 0;

        try {

            connection = new CarWashManagerDatabase();
            int numOfBookings = this.getNumberofBookings(connection);

            ArrayList<Booking> bookings = connection.viewAllBookings();

            for (Booking booking : bookings) {
                String status = booking.getBookingStatus();
                if (status.equals("NOT YET STARTED")) {
                    numOfNotYet++;
                } else if (status.equals("HALFWAY")) {
                    numOfHalfway++;
                }
            }
            String halfway = "Number of bookings that are halfway: " + numOfHalfway;
            String notYet = "Number of bookings that are yet to be started: " + numOfNotYet;
            
            int numOfWashedCars = connection.viewWashedCars().size();

            bw.write("Number of Bookings: " + numOfBookings + "\n");
            bw.write("Number of Finished Bookings: " + numOfWashedCars + "\n");

            bw.write(halfway + "\n");
            bw.write(notYet + "\n");

            request.setAttribute("numOfBookings", numOfBookings);
            request.setAttribute("numOfFinished", numOfWashedCars);
            request.setAttribute("half", halfway);
            request.setAttribute("notyet", notYet);

            request.setAttribute("bookings",bookings);
            
        } catch (SQLException ex) {
            Logger.getLogger(FourthReportAdmin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FourthReportAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }

        bw.close();

        request.getRequestDispatcher("FourthReportAdminDisplay.jsp").forward(request, response);
    }

    private int getNumberofBookings(CarWashManagerDatabase connection)
            throws SQLException, ClassNotFoundException {

        String sql = "SELECT COUNT(Id) AS count FROM carwashmanagementsystemdb.wash";
        // Using try-with-resources to ensure resources are closed properly
        try (
                PreparedStatement ps = connection.getConnection().prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            // Retrieve the number of complaints
            if (rs.next()) {
                return rs.getInt("count");
            } else {
                // In case the result set is empty
                return 0;
            }
        }
    }
}
