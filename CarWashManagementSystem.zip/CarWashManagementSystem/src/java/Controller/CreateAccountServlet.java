package Controller;

import Database.CarWashManagerDatabase;
import Entities.Account;
import Entities.Customer;
import Exceptions.InvalidIdentityNumberException;
import Exceptions.InvalidPasswordException;
import Exceptions.PasswordsDoesNotMatchException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig
public class CreateAccountServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //String termsAndConditions = request.getParameter("termsAndConditions");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        String idNumber = request.getParameter("idNumber");
        try {
            if (isValidIdentityNumber(idNumber)) {

                if (isValidPassword(password)) {
                    if (passwordsMatch(password, confirmPassword)) {

                        Account account = new Account(username, password);
                        Customer customer = new Customer(firstName, lastName, idNumber, email, account);
                        CarWashManagerDatabase connection = null;

                        connection = new CarWashManagerDatabase();
                        connection.addCustomer(customer);

                    } else {
                        throw new PasswordsDoesNotMatchException("Your Password(" + password + ") and Confirm Password(" + confirmPassword + ") does not match.");
                    }
                } else {
                    throw new InvalidPasswordException(password + " does not conform to our password standards. A Valid password should have: \n\n"
                            + "8 or more characters,\n"
                            + "2 or more uppercase,\n"
                            + "2 0r more digits,\n"
                            + "1 or more lowercase, and \n"
                            + "1 or more special characters\n");
                }
            } else {
                throw new InvalidIdentityNumberException(idNumber + " Is not a valid South African ID. Please consider the Length, the Day, and Month of your ID.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(CreateAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CreateAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (PasswordsDoesNotMatchException e) {
            request.setAttribute("PasswordsDoesNotMatchException", e);
            request.getRequestDispatcher("/PasswordsDoesNotMatchException.jsp").forward(request, response);
        } catch (InvalidPasswordException e) {
            request.setAttribute("InvalidPasswordException", e);
            request.getRequestDispatcher("/InvalidPasswordException.jsp").forward(request, response);
        } catch (InvalidIdentityNumberException e) {
            request.setAttribute("InvalidIdentityNumberException", e);
            request.getRequestDispatcher("/InvalidIdentityNumberException.jsp").forward(request, response);
        }

        request.getRequestDispatcher("Login.jsp").forward(request, response);
    }//end

    private boolean isValidIdentityNumber(String idNumber) {

        boolean isValid = false;
        for (int i = 0; i < idNumber.length(); i++) {

            char singleChar = idNumber.charAt(i);
            if (!Character.isDigit(singleChar)) {
                return isValid;
            }

            if (idNumber.length() == 13) {

                int month = Integer.parseInt(idNumber.substring(2, 4));
                if (month > 0 && month < 13) {

                    int day = Integer.parseInt(idNumber.substring(4, 6));
                    if (day > 0 && day < 32) {
                        isValid = true;
                    } else {
                        return isValid;
                    }

                } else {
                    return isValid;
                }
            } else {
                return isValid;
            }

        }//end loop
        return isValid;
    }//end

    private boolean isValidPassword(String password) {
        int lower = 0, upper = 0, digit = 0, special = 0, characters = 0;

        for (char singlerChar : password.toCharArray()) {
            characters++;
            if (Character.isLetter(singlerChar)) {

                if (Character.isUpperCase(singlerChar)) {
                    upper++;
                } else {
                    lower++;
                }

            } else if (Character.isDigit(singlerChar)) {
                digit++;
            } else if (!Character.isLetterOrDigit(singlerChar)) {
                special++;
            }
        }//end loop

        return (characters >= 8 && upper >= 1 && lower >= 2 && digit >= 2 && special >= 1);
    }//end

    private boolean passwordsMatch(String password, String confirmPassword) {
        return password.equals(confirmPassword);
    }//end

    private String encyptPassword(String password) {

        String encryptedPassword = "";

        for (int i = 0; i < password.length(); i++) {

            char singleChar = password.charAt(i);
            int integerCharacterValue = (int) singleChar;
            int integerPlacesAway = 0;

            if (integerCharacterValue % 2 == 0) {//even number

                integerPlacesAway = 2;
                integerCharacterValue += integerPlacesAway;

            } else {//odd number

                integerPlacesAway = 2;
                integerCharacterValue -= integerPlacesAway;
            }
            encryptedPassword += (char) integerCharacterValue;
        }
        return encryptedPassword;
    }//end

    private String decryptPassword(String password) {

        String decryptedPassword = "";
        for (int i = 0; i < password.length(); i++) {

            char singleChar = password.charAt(i);
            int integerCharacterValue = (int) singleChar;
            int integerPlacesAway = 0;

            if (integerCharacterValue % 2 == 0) {

                integerPlacesAway = 2;
                integerCharacterValue -= integerPlacesAway;
            } else {
                integerPlacesAway = 2;
                integerCharacterValue += integerPlacesAway;

            }

            decryptedPassword += Character.toString((char) integerCharacterValue);
        }

        return decryptedPassword;
    }//end

    private byte[] convertImageToByte(Part image) {

        InputStream imageStream = null;
        byte[] imageBLOB = null;
        ByteArrayOutputStream baos = null;
        byte[] buffer = null;

        try {

            imageStream = image.getInputStream();
            baos = new ByteArrayOutputStream();
            buffer = new byte[1024];
            int read_byte = 0;

            while ((read_byte = imageStream.read(buffer)) != -1) {
                baos.write(buffer, 0, read_byte);
            }

            imageBLOB = baos.toByteArray();

        } catch (IOException ex) {
            Logger.getLogger(CreateAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                imageStream.close();
            } catch (IOException ex) {
                Logger.getLogger(CreateAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return imageBLOB;
    }//end

}

//C:\Users\pales\AppData\Local\Temp\CarWashManagementSystem.zip
//C:\Users\pales\AppData\Local\Temp\CarWashManagementSystem.zip
