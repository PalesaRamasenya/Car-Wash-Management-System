package Controller;

import Database.CarWashManagerDatabase;
import Entities.Booking;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SecondReportAdmin extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("C:\\Users\\pales\\Desktop\\CarsAndWashtypes.txt")));

        String suvStr = "The number of SUV's: ";
        String sedanStr = "The number of Sedans: ";
        String vanStr = "The number of Vans: ";
        String truckStr = "The number of Trucks: ";
        String convertibleStr = "The number of Convertibles: ";
        String otherStr = "Other models: ";

        String autoStr = "Automatic Car Wash was chosen by ", fullStr = "Full Service Car Wash was chosen by ",
                selfStr = "Self Service Car Wash was chosen by ";
        try {

            CarWashManagerDatabase connection = new CarWashManagerDatabase();
            int sedan = 0, van = 0, suv = 0, truck = 0, convertible = 0, other = 0;

            int auto = 0, self = 0, full = 0;
            int numOfWashedCars = 0;

            ArrayList<Booking> bookings = connection.viewAllBookings();
            request.setAttribute("bookings", bookings);
            
            for (Booking booking : bookings) {

                //determines most washed car type
                String type = booking.getCar().getCarType();

                if (type.equals("SUV")) {
                    suv++;
                } else if (type.equals("Sedan")) {
                    sedan++;
                } else if (type.equals("Truck")) {
                    truck++;
                } else if (type.equals("Van")) {
                    van++;
                } else if (type.equals("Convertible")) {
                    convertible++;
                } else {
                    other++;
                }

                //most chosen wasty type
                String washtype = booking.getWash().getWashType();

                if (washtype.equals("Full Service Car Wash")) {
                    full++;
                } else if (washtype.equals("Automatic Car Wash")) {
                    auto++;
                } else {
                    self++;
                }

                //number of washed cars
                if (booking.getBookingStatus().equals("FINISHED")) {
                    numOfWashedCars++;
                }

            }//end loop

            autoStr += auto + " Customers.";
            fullStr += full + " Customers.";
            selfStr += self + " Customers.";

            //determine most and least used washtypes
            String most = "", least = "";
            if (full > self && full > auto) {
                most = "The most used wash type is: Full Service Car Wash";
            }

            if (self > full && self > auto) {
                most = "The most used wash type is: Self Service Car Wash";
            }

            if (auto > self && auto > full) {
                most = "The most used wash type is: Automatic Car Wash";
            }

            if (full < self && full < auto) {
                least = "The least used wash type is: Full Service Car Wash";
            }

            if (self < full && self < auto) {
                least = "The least used wash type is: Self Service Car Wash";
            }

            if (auto < self && auto < full) {
                least = "The least used wash type is: Automatic Car Wash";
            }

            vanStr += van;
            suvStr += suv;
            truckStr += truck;
            convertibleStr += convertible;
            otherStr += other;
            sedanStr += sedan;

            //write to file
            bw.write("The total number of washed cars: " + numOfWashedCars + "\n");
            bw.write(vanStr + "\n");
            bw.write(suvStr + "\n");
            bw.write(truckStr + "\n");
            bw.write(convertibleStr + "\n");
            bw.write(otherStr + "\n");
            bw.write(sedanStr + "\n");

            bw.write(most + "\n");
            bw.write(least + "\n");

            //setting the request objects
            request.setAttribute("vanStr", vanStr);
            request.setAttribute("suvStr", suvStr);
            request.setAttribute("truckStr", truckStr);
            request.setAttribute("convertibleStr", convertibleStr);
            request.setAttribute("otherStr", otherStr);
            request.setAttribute("sedanStr", sedanStr);

            request.setAttribute("least", most);
            request.setAttribute("most", least);

            request.setAttribute("autoStr", autoStr);
            request.setAttribute("selfStr", selfStr);
            request.setAttribute("fullStr", fullStr);
            request.setAttribute("washed", numOfWashedCars);

        } catch (SQLException ex) {
            Logger.getLogger(SecondReportAdmin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SecondReportAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }

        bw.close();

        request.getRequestDispatcher(
                "SecondReportAdminDisplay.jsp").forward(request, response);
    }
}
